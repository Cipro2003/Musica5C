package com.example.musica5c;
public class GestioneBrani {

    public void addBrano(){

      }
    public String visualizzaTitolo(String autore)
    {
        String testo=autore;
        return testo;
    }
}